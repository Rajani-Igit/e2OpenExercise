package com.e2open.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E2OpenDeliveryPlanApplication {

	public static void main(String[] args) {
		SpringApplication.run(E2OpenDeliveryPlanApplication.class, args);
	}

}
