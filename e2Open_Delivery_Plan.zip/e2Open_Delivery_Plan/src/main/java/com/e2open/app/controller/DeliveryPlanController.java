package com.e2open.app.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.e2open.app.dto.DeliveryPlan;
import com.e2open.app.service.DeliveryPlanService;

@RestController
public class DeliveryPlanController {
	@Autowired
	private DeliveryPlanService deliveryPlanService;

	@GetMapping("/duedaterange")
	public List<DeliveryPlan> showDeliveryplanwitdueDateRange() {
		return null;

	}

	@GetMapping("/")
	public List<DeliveryPlan> showDeliveryplan() {
		Pageable pageable = PageRequest.of(0, 10);
		Page<DeliveryPlan> page = deliveryPlanService.findAll(pageable);
		return page.getContent();

	}

	@PostMapping(path = "/add") 
	public String addNewDeliveryDetails() {
//@RequestBody DeliveryPlan deliveryplan1
		DeliveryPlan deliveryplan = new DeliveryPlan();
		deliveryplan.setCustomer("CUST-1");
		deliveryplan.setDeliveryno(101);
		deliveryplan.setDeliverydate(new Date());
		deliveryplan.setDepot("Hyderabad");
		deliveryplan.setDuedate(new Date());
		deliveryplan.setMargin("1000 $");
		deliveryplan.setPart("Hard disk");
		deliveryplan.setQuantity(10);

		deliveryPlanService.save(deliveryplan);
		return "Saved";
	}

	@GetMapping("/fetchbydeliveryno/{delevery_no}")
	public List<DeliveryPlan> getDeliveryPlan(@PathVariable(name = "delevery_no") int deliverid) {
		return deliveryPlanService.fetchByDeliveryno(deliverid);

	}

	@GetMapping("/fetchbycustomer/{customer}")
	public List<DeliveryPlan> getDeliveryPlanBycustomerdtls(@PathVariable(name = "customer") String customer) {
		return deliveryPlanService.fetchByCustomer(customer);
	}

	@GetMapping("/fetchbypart/{part}")
	public List<DeliveryPlan> getDeliveryPlanBypart(@PathVariable(name = "part") String part) {
		return deliveryPlanService.fetchByPart(part);
	}

	@GetMapping("/fetchbydepot/{depot}")
	public List<DeliveryPlan> getDeliveryPlanBydepot(@PathVariable(name = "depot") String depot) {
		return deliveryPlanService.fetchByDepot(depot);
	}
}
