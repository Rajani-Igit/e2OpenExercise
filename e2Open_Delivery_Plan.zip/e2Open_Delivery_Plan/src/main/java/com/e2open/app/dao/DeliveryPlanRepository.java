package com.e2open.app.dao;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.e2open.app.dto.DeliveryPlan;
public interface DeliveryPlanRepository extends JpaRepository<DeliveryPlan,Integer> {
   /* @Query("SELECT t FROM Thing t WHERE t.fooIn = ?1 AND t.bar = ?2")
    DeliveryPlan findByFooInAndBar(String fooIn, String bar);*/
   public List<DeliveryPlan>   findByDeliveryno(int deliveryno);
   public List<DeliveryPlan>  findByCustomer(String customer);
   public List<DeliveryPlan>  findByDuedate(int duedate);
   public List<DeliveryPlan>  findByQuantity(int quantity);
   public  List<DeliveryPlan>  findByDeliverydate(int date);
   public  List<DeliveryPlan>  findByPart(String part);
   public  List<DeliveryPlan>  findByDepot(String depot);
   
    @Query(value = "from DeliveryPlan t where duedate BETWEEN :startDate AND :endDate")
    public List<DeliveryPlan> getAllBetweenDates(@Param("startDate")Date startDate,@Param("endDate")Date endDate);
}


