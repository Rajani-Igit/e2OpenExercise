package com.e2open.app.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DeliveryPlan {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int deliveryno;
	private String part;
	private String depot;
	private String customer;
	private  int quantity;
	private  Date duedate;
	private Date deliverydate;
	private String margin;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getDeliveryno() {
		return deliveryno;
	}
	public void setDeliveryno(int deliveryno) {
		this.deliveryno = deliveryno;
	}
	public String getPart() {
		return part;
	}
	public void setPart(String part) {
		this.part = part;
	}
	public String getDepot() {
		return depot;
	}
	public void setDepot(String depot) {
		this.depot = depot;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Date getDuedate() {
		return duedate;
	}
	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}
	public Date getDeliverydate() {
		return deliverydate;
	}
	public void setDeliverydate(Date deliverydate) {
		this.deliverydate = deliverydate;
	}
	public String getMargin() {
		return margin;
	}
	public void setMargin(String margin) {
		this.margin = margin;
	}
	
}
