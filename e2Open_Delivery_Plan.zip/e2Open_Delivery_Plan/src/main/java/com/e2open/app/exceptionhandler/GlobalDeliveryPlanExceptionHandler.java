package com.e2open.app.exceptionhandler;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.e2open.app.dto.DeliveryplanError;

@RestControllerAdvice
public class GlobalDeliveryPlanExceptionHandler {
	@ExceptionHandler(Exception.class)
	public DeliveryplanError genericExceptionHandler(Exception ex) {
		DeliveryplanError error=new DeliveryplanError();
		error.setErrorcode(123);
		error.setErrormessage(ex.getMessage());
		return error;
		
	}

}
