package com.e2open.app.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.e2open.app.dto.DeliveryPlan;

public interface DeliveryPlanService {
	   public List<DeliveryPlan>   fetchByDeliveryno(int deliveryno);
	   public List<DeliveryPlan>  fetchByCustomer(String customer);
	   public List<DeliveryPlan>  fetchByDuedate(int duedate);
	   public List<DeliveryPlan>  fetchByQuantity(int quantity);
	   public  List<DeliveryPlan>  fetchByDeliverydate(int date);
	   public  List<DeliveryPlan>  fetchByPart(String part);
	   public  List<DeliveryPlan>  fetchByDepot(String depot);
	   public void save(DeliveryPlan deliveryplan);
	   public Page<DeliveryPlan> findAll(Pageable pageable);    
}
