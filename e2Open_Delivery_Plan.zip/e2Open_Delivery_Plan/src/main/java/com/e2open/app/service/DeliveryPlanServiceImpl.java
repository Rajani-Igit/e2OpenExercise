package com.e2open.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.e2open.app.dao.DeliveryPlanRepository;
import com.e2open.app.dto.DeliveryPlan;
@Service
public class DeliveryPlanServiceImpl implements DeliveryPlanService {
	@Autowired
	private DeliveryPlanRepository deliveryPlanRepository;
	@Override
	public List<DeliveryPlan> fetchByDeliveryno(int deliveryno) {
		return deliveryPlanRepository.findByDeliveryno(deliveryno);
	}

	@Override
	public List<DeliveryPlan> fetchByCustomer(String customer) {
		return deliveryPlanRepository.findByCustomer(customer);
	}

	@Override
	public List<DeliveryPlan> fetchByDuedate(int duedate) {
		return null;
	}

	@Override
	public List<DeliveryPlan> fetchByQuantity(int quantity) {
		return null;
	}

	@Override
	public List<DeliveryPlan> fetchByDeliverydate(int date) {
		return null;
	}

	@Override
	public List<DeliveryPlan> fetchByPart(String part) {
		return deliveryPlanRepository.findByPart(part);
	}

	@Override
	public List<DeliveryPlan> fetchByDepot(String depot) {
		return deliveryPlanRepository.findByDepot(depot);

	}

	@Override
	public void save(DeliveryPlan deliveryplan) {
		deliveryPlanRepository.save(deliveryplan);
		
	}

	@Override
	public Page<DeliveryPlan> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return deliveryPlanRepository.findAll(pageable);
	}

}
